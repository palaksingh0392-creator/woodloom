import { NextResponse } from "next/server";

import {
  parseCollectionInput,
  upsertAdminCollection,
} from "@/lib/admin-taxonomy";
import { canAccessAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getCurrentSession } from "@/lib/session";

type RouteContext = { params: Promise<{ id: string }> };

async function authorize() {
  const session = await getCurrentSession();
  return Boolean(session && canAccessAdmin(session.role));
}

export async function PATCH(request: Request, context: RouteContext) {
  if (!(await authorize())) {
    return NextResponse.json({ message: "Admin access required." }, { status: 401 });
  }

  try {
    const { id } = await context.params;
    const collection = await upsertAdminCollection(
      parseCollectionInput(await request.json()),
      id,
    );
    return NextResponse.json({ collection });
  } catch (error) {
    return NextResponse.json(
      {
        message:
          error instanceof Error ? error.message : "Could not update collection.",
      },
      { status: 400 },
    );
  }
}

export async function DELETE(_request: Request, context: RouteContext) {
  if (!(await authorize())) {
    return NextResponse.json({ message: "Admin access required." }, { status: 401 });
  }

  const { id } = await context.params;
  const hardDelete = new URL(_request.url).searchParams.get("hard") === "true";

  if (hardDelete) {
    await prisma.collection.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  }

  const collection = await prisma.collection.update({
    where: { id },
    data: { isActive: false },
  });

  return NextResponse.json({ collection });
}
